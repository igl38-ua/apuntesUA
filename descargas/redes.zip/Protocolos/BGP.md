BGP - Border Gateway Protocol.

*Encaminamiento entre SA (Sistemas Autónomos).* 

# Relacionado
[[OSPF]]
[[RIP]]

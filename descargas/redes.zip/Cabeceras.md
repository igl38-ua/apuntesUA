| Protocolo | TCP | IP  | ICMP | Ethernet |
| --------- | --- | --- | ---- | -------- |
| Tamaño    | 20  | 20  | 8    | 14       |

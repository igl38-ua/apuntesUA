En lugar de utilizar recursión es iterativo.
Resuelve primero las soluciones más simples y usa sus soluciones para resolver los subproblemas más pequeños.

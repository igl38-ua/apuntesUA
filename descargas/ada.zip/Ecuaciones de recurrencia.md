Expresan la complejidad de un algoritmo. Son aplicables a algoritmos iterativos.

- Si el algoritmo tiene mejor y peor caso puede haber una ecuación de recurrencia para cada caso.
- Se resuelven mediante el método de sustitución. Solo para funciones lineales, recursividad simple.


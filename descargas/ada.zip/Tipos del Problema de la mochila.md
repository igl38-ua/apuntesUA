# Programación dinámica

[[El problema de la mochila (knapsack problem)]]
- Objetos no fragmentables y pesos discretos. 

___
# Algoritmos voraces

[[El problema de la mochila continua]] (aplicable) Mejor solución.
[[El problema de la mochila discreta (sin fraccionamiento)]] (no aplicable)
- Objetos fragmentables.

___
# Back tracking

[[El problema de la mochila (general)]]
- Objetos no fragmentables y los pesos son valores reales. 

> [!example] Datos
> - $v_i$ son los valores del total
> - $w_i$ son los pesos
> - $W$ es la capacidad de la mochila

El método voraz no resuelve el problema.

![[mochila-discreta.png]]



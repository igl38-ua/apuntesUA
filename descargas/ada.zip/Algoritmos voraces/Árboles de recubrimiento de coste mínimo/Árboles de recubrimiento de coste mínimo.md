- Grafos $g = (V, A)$
	- conexo (todos los nodos son alcanzables desde cualquier nodo, no hay islas)
	- no dirigido
	- arcos ponderados
	- con arcos positivos
Se busca el **árbol de recubrimiento de coste mínimo**. 
Se trata de un subgrafo de g que contiene todos los vértices, es conexo, no tiene ciclos (definición de árbol) y de coste mínimo.




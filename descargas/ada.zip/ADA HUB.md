Árbol de contenidos.
# Mecanismos de resolución de algoritmos
## [[Divide y vencerás]]

![[Divide y vencerás#Definición]]
## [[Programación dinámica]]

![[Programación dinámica#Definición]]
## [[Algoritmos voraces]]

![[Algoritmos voraces#Definición]]
## [[Back tracking]]

![[Back tracking#Definición]]
## [[Ramificación y poda]]

![[Ramificación y poda#Definición]]

---
# [[Complejidad y notación asintótica]]
# [[Cálculo de complejidades básicas]]
# [[Ecuaciones de recurrencia]]

![[Ecuaciones de recurrencia]]
# [[Tipos del Problema de la mochila]]

![[Tipos del Problema de la mochila]]
# [[Conceptos clave]]

- Subestructura óptima o principio de optimalidad
# [[2 Areas/ADA/Tests/Preguntas test|Preguntas test]]
# [[ada-nuevo.pdf|PDF ADA]]
